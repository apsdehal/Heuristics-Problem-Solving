for i in range(1,101):
	if i%40 == 0:
		print i
	else:
		print i,
